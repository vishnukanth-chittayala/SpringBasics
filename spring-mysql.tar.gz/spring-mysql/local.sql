create database ticket;
use ticket;