package com.java.spring.mysql.api.dao;

import org.springframework.data.jpa.repository.support.CrudMethodMetadata;
import org.springframework.data.repository.CrudRepository;

import com.java.spring.mysql.api.model.Ticket;

public interface TicketDao extends CrudRepository< Ticket, Integer> {

}
